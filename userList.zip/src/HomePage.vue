<template>
  <div class="container">
    <!-- <HeaderComponent /> -->
    
      <div class="head-condainer">
      <div class="serach-container">
        <div class="bannerHeading">
              <!-- <h1>Discover the world of events</h1> -->
              
                <div>
                <span class="p-input-icon-left ">
                    <i class="pi pi-search" />
                    <InputText class="Searchinput" type="text" v-model="nameUser" />
                    
                </span>
                <div class="card" v-for="(item,index) in cardName" :key="index">
                  <Card>
                   
                      <template #content>
                          <div class="cardInside" >
                            <!-- <input type="text" v-model="item.name"> -->
                            <span><p> {{item.name}}</p></span>
                            <span><p>dfs</p></span>
                            <span><p>dfs</p></span>
                          </div>
                      </template>
                      
                  
                </Card>
                <!-- <Card>
                  <template #content>
                          <div class="cardInside">
                            <span><p>saxbnhbhh</p></span>
                            <span><p>dfs</p></span>
                            <span><p>dfs</p></span>
                          </div>
                      </template>
                </Card> -->
                <!-- <Card>
                  <template #content>
                          <div class="cardInside">
                            <span><p>saxbnhbhh</p></span>
                            <span><p>dfs</p></span>
                            <span><p>dfs</p></span>
                          </div>
                      </template>
                </Card> -->
                </div>
              </div>
              

              
        </div>
        
      </div>
      
    </div>
    
    
    
    
  </div>
  
</template>

<script>
// import HeaderComponent from "./components/HeaderComponent.vue";
import InputText from 'primevue/inputtext';
import Card from 'primevue/card';
import { addDoc, collection, onSnapshot,query } from 'firebase/firestore';
import db from "./db-connection/db";
import { onUnmounted } from 'vue';

export default {
  listData: null,
  name: 'HomePage',
  components: {
    // HeaderComponent,
    InputText,
    Card
     // Register the component locally
  },
  // props: {
  //   msg: String
  // }
  data (){
    return{
      name: null,
      searchData: null,
      nameUser: '',
      nameDep:'',
      nameDesig:'',
      cardName: null

    }
  },
  mounted(){
    var name = [];
    const listData = query(collection(db,"user"));
    const cardNameData = onSnapshot(listData,(snapshot)=>{
      var cardName = snapshot.docs.map((doc)=>{
        
        if (doc.exists()) {
          let obj = { name : doc.data().name};
          name.push(obj);
        } else {
          console.log("No such document!");
        }
        return cardName;
      })
    });

    this.cardName = name;
    console.log('this.cardName', this.cardName);
    
    onUnmounted(cardNameData)
  },
  
  methods:{
    
    newEvent(){
      this.$router.push('/new');
    },
    listEvent(){
      this.$router.push('/list');
    },
    addUser(){
      addDoc(collection(db,'user'),{
        name:this.nameUser,
        designation:this.nameDesig,
        department:this.nameDep
      });
      
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
