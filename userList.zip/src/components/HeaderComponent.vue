<template>
  <header>
    <div class="header">
      <h2>WORLD OF EVENTS</h2>
      <div class="activity">
        <p>Add My Event</p>
        <p>Up Comming Events</p>
      </div>
    </div>
  </header>
</template>

<script>
export default {
  name: 'HeaderComponent',
  
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
